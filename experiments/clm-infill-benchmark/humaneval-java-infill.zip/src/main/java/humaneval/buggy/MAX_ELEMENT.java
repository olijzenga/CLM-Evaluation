package humaneval.buggy;

import java.util.List;

public class MAX_ELEMENT {
    public static int max_element(List<Integer> l) {
        int m = l.get(0);
        <mask>
            if (e > m){
                m = e;
            }
        }
        return m;
    }
}
