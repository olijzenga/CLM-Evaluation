package humaneval.buggy;

public class LARGEST_DIVISOR {
    public static int largest_divisor(int n) {
        <mask>
            if (n % i == 0)
                return i;
        }
        return 1;
    }
}
