package humaneval.buggy;

public class STRLEN {
    public static int strlen(String string){
        <mask>
    }
}
