package humaneval.buggy;

public class TRUNCATE_NUMBER {
    public static double truncate_number(double number) {
        <mask>
    }
}
