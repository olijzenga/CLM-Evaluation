package humaneval.buggy;

public class CONCATENATE {
    public static String concatenate(String[] strings) {
        String result = "";
        <mask>
            result += string;
        return result;
    }
}
